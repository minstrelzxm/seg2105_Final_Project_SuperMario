# seg2105_Final_Project_SuperMario

Xumou Zhang 8474153
Yuxuan Jiang 8235509
Mingwei Deng 7847379
Jichao An 8300233
Dengyu Liang 300019847

We used firebase as the database in delieverable 1.
delieverable 2:
We include the test case files in android test folder. 
2 test files in total.

https://github.com/minstrelzxm/seg2105_Final_Project_SuperMario.git