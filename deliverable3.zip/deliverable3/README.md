# seg2105_Final_Project_SuperMario

Xumou Zhang 8474153
Yuxuan Jiang 8235509
Mingwei Deng 7847379
Jichao An 8300233
Dengyu Liang 300019847

We used firebase as the database in delieverable 1.
delieverable 2:
We include the test case files in android test folder. 
2 test files in total.

delieverable 3: 
We used firebase as the database in delieverable 3.
The procedure of this deliverable is:
1. create a Service Provider account.
2. login into account.
3. press info, enter info and press save. // You will see the info occur on the screen which save in the firebase.
4. (optional) press change Info to change the info data and save again.
5. press AddService and enter the service.
6. return to the Service Provider main page and the serivice will occur on the screen.
7. press Avilibilities (the right one) to enter the time schedule and enter time with checkbox.
8. done. (The unit test is included)

https://github.com/minstrelzxm/seg2105_Final_Project_SuperMario.git
